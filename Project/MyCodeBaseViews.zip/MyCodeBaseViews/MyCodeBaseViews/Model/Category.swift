//
//  Category.swift
//  MyCodeBaseViews
//
//  Created by 구태호 on 2023/09/26.
//

import Foundation

struct Category {
    var title: String
    var isShowDivide: Bool = false
}
