//
//  UITableViewCell+.swift
//  MyCodeBaseViews
//
//  Created by 구태호 on 11/21/23.
//

import UIKit


extension UITableViewCell {
    func defaultSelectionStyle() {
        selectionStyle = .none
    }
}
